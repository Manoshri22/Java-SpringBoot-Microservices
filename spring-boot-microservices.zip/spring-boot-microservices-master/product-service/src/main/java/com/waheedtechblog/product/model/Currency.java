/**
 * 
 */
package com.waheedtechblog.product.model;

/**
 * @author Abdul
 *
 */
public enum Currency {
	INR,
}
