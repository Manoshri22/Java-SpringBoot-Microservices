API Gateway - Spring Cloud Zuul
============================================

Copyright (c) 2019, [WaheedTechblog](http://www.waheedtechblog.com/).

Contributor: Abdul Waheed [abdulwaheed18@gmail.com]

[https://github.com/abdulwaheed18/spring-boot-microservices](https://github.com/abdulwaheed18/spring-boot-microservices)

** API Gateway Endpoint URL** http://localhost:7005/product/products/1
