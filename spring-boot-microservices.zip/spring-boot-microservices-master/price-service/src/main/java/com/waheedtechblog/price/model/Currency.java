/**
 * 
 */
package com.waheedtechblog.price.model;

/**
 * @author Abdul
 *
 */
public enum Currency {
	INR,
}
