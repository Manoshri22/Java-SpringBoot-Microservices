/**
 * 
 */
package com.waheedtechblog.feignclient.model;

/**
 * @author Abdul
 *
 */
public enum Currency {
	INR,
}
